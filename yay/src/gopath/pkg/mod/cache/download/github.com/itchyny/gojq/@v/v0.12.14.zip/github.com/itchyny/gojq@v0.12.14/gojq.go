// Package gojq provides the parser and the interpreter of gojq.
// Please refer to [Usage as a library] for introduction.
//
// [Usage as a library]: https://github.com/itchyny/gojq#usage-as-a-library
package gojq
